package com.contactmanager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Random;

public class ContactManagerGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private ContactDAO contactDAO;
    private JTextField nameField, emailField, phoneField, searchField;
    private JButton addButton, updateButton, deleteButton, searchButton, displayButton;
    private JTable contactTable;
    private DefaultTableModel tableModel;

    public ContactManagerGUI() {
        // Initialize ContactDAO
        contactDAO = new ContactDAO();

        // Initialize JFrame
        setTitle("Contact Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);

        // Initialize components
        nameField = new JTextField(20);
        emailField = new JTextField(20);
        phoneField = new JTextField(20);
        searchField = new JTextField(20);
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        searchButton = new JButton("Search");
        displayButton = new JButton("Display All");

        // Add action listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addContact();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateContact();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteContact();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchContacts();
            }
        });

        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllContacts();
            }
        });

        // Add components to JFrame
        setLayout(new FlowLayout());
        add(new JLabel("Name:"));
        add(nameField);
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Phone:"));
        add(phoneField);
        add(addButton);
        add(updateButton);
        add(deleteButton);
        add(new JLabel("Search:"));
        add(searchField);
        add(searchButton);
        add(displayButton);

        // Initialize table
        String[] columnNames = {"ID", "Name", "Email", "Phone"};
        tableModel = new DefaultTableModel(columnNames, 0);
        contactTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(contactTable);
        add(scrollPane);

        // Set JFrame visibility
        setVisible(true);

        // Start continuous color change
        startContinuousColorChange();
    }

    private void addContact() {
        String name = nameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        Contact contact = new Contact(0, name, email, phone);
        contactDAO.insertContact(contact);
        refreshTable();
        showSuccessMessage("Contact added successfully!");
    }

    private void updateContact() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow != -1) {
            int contactId = Integer.parseInt(JOptionPane.showInputDialog("Enter new ID:"));
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            Contact contact = new Contact(contactId, name, email, phone);
            contactDAO.updateContact(contact);
            refreshTable();
            showSuccessMessage("Contact updated successfully!");
        } else {
            showErrorMessage("Please select a contact to update.");
        }
    }

    private void deleteContact() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow != -1) {
            int contactId = (int) contactTable.getValueAt(selectedRow, 0);
            contactDAO.deleteContact(contactId);
            refreshTable();
            showSuccessMessage("Contact deleted successfully!");
        } else {
            showErrorMessage("Please select a contact to delete.");
        }
    }

    private void searchContacts() {
        String searchTerm = searchField.getText();
        List<Contact> searchResults = contactDAO.searchContacts(searchTerm);
        displayContacts(searchResults);
    }

    private void displayAllContacts() {
        refreshTable();
    }

    private void refreshTable() {
        // Clear existing data
        tableModel.setRowCount(0);

        // Get all contacts from ContactDAO
        List<Contact> contacts = contactDAO.getAllContacts();

        // Add contacts to the table
        for (Contact contact : contacts) {
            Object[] rowData = {contact.getId(), contact.getName(), contact.getEmail(), contact.getPhoneNumber()};
            tableModel.addRow(rowData);
        }
    }

    private void displayContacts(List<Contact> contacts) {
        // Clear existing data
        tableModel.setRowCount(0);

        // Add contacts to the table
        for (Contact contact : contacts) {
            Object[] rowData = {contact.getId(), contact.getName(), contact.getEmail(), contact.getPhoneNumber()};
            tableModel.addRow(rowData);
        }
    }

    private void showSuccessMessage(String message) {
        setRandomBackgroundColor();
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showErrorMessage(String message) {
        setRandomBackgroundColor();
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void setRandomBackgroundColor() {
        Random random = new Random();
        Color randomColor = new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256));
        getContentPane().setBackground(randomColor);
    }

    private void startContinuousColorChange() {
        Timer timer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setRandomBackgroundColor();
            }
        });
        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ContactManagerGUI();
            }
        });
    }
}
